﻿using System.ComponentModel.DataAnnotations;

namespace JsonWebTokenProject.ViewModel
{
    public class ResponseModel
    {
        public string Messsage { get; set; }
        public int Code { get; set; }
        public string Token { get; set; }
    }
    public class GetPatient
    {
        public int PatientId { get; set; }
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string? PhoneNumber { get; set; }
        public DateTime? Dob { get; set; }
        //public string CountryName { get; set; }
        //public int CountryID { get; set; }
        public string UserName { get; set; } = null!;
        public bool IsActive { get; set; }
        public string? CreatedByl { get; set; }
        public DateTime? CreatedOn { get; set; }
        //    public string? UpdatedBy { get; set; }
        //    public DateTime? UpdatedOn { get; set; }
        //    public string? DeletedBy { get; set; }
        //    public DateTime? DeletedOn { get; set; }
        //    public bool IsDeleted { get; set; }
        //}
    }


    public class LoginModel
    {
        [Required]
        public string UserName { get; set; }
        [Required]
        public string Password { get; set; }
    }
}
