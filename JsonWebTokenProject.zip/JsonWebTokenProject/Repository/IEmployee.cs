﻿using JsonWebTokenProject.Controllers;
using JsonWebTokenProject.ViewModel;

namespace JsonWebTokenProject.Repository
{
    public interface IEmployee
    {
        public List<GetPatient> GetEmployeeWithDpt();

        public ResponseModel Login(LoginModel info);
    }
}
