﻿
using JsonWebTokenProject.Controllers;
using JsonWebTokenProject.Model;
using JsonWebTokenProject.ViewModel;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace JsonWebTokenProject.Repository
{
    public class Employee : IEmployee

    {
        private IConfiguration _config;
        public Employee(IConfiguration config)
        {
            _config = config;
        }

        //ToGenerateToken
        private string GenerateJSONWebToken(LoginModel userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
             {
                 new Claim(ClaimTypes.Name, userInfo.UserName),
                 new Claim(ClaimTypes.Email, "admin@gmail.com"),
                 new Claim(ClaimTypes.Sid, "101"),
                 new Claim(ClaimTypes.Role , "admin"),
                 new Claim(ClaimTypes.Role , "Doctor")
             };

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
              _config["Jwt:Issuer"],
              null,
              expires: DateTime.Now.AddMinutes(120),
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }



        public List<GetPatient> GetEmployeeWithDpt()
        {
            sdirectdbContext dbcontex = new sdirectdbContext();

            var Obj = (from patient in dbcontex.ApiPatients
                       where patient.IsDeleted == false
                       //join dpt in dbcontex.ApiCountries on patient.CountryId equals dpt.CountryId
                       orderby patient.PatientId descending
                       select new GetPatient
                       {
                           PatientId = patient.PatientId,
                           FirstName = patient.FirstName,
                           LastName = patient.LastName,
                           UserName = patient.UserName,
                           Dob = patient.Dob,
                           Email = patient.Email,
                           PhoneNumber = patient.PhoneNumber,
                           CreatedByl = patient.CreatedByl,
                           CreatedOn = patient.CreatedOn,
                           //UpdatedBy = patient.UpdatedBy,
                           //CountryName = dpt.Countryname,
                           //UpdatedOn = patient.UpdatedOn,
                           IsActive = patient.IsActive,
                       }
                        ).ToList();
            return Obj;
        }

        

        public ResponseModel Login(LoginModel info)
        {
            ResponseModel response = new ResponseModel();
            sdirectdbContext _dbcontext = new sdirectdbContext();
           
                var Obj = (from data in _dbcontext.ApiLogins
                           where data.Username == info.UserName && data.Password == info.Password
                           select new LoginModel
                           {
                               UserName = info.UserName,
                               Password = info.Password,
                           }
                       ).FirstOrDefault();

                if (Obj != null)
                {
                    response.Messsage = "okie";
                    //response.Code =  EnsureSuccessStatusCode();
                    response.Code = 200;
                    response.Token = GenerateJSONWebToken(info);
                    return response;
                }
                response.Messsage = "E";
                response.Code = 500;
                return response;
            
        }
    }
}
