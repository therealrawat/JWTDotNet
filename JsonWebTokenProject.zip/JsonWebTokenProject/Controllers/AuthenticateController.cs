﻿using JsonWebTokenProject.Repository;
using JsonWebTokenProject.ViewModel;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.Text;

namespace JsonWebTokenProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticateController : BaseController
    {
        
        private IEmployee _context;
        public AuthenticateController(IConfiguration config, IEmployee context)
        {
            _context = context;
        }


        [AllowAnonymous]
        [HttpPost(nameof(AuthLogin))]
        public IActionResult AuthLogin(LoginModel login)
        {
            return Ok(_context.Login(login));
        }



        //[Authorize(Roles = "admin")]
        [HttpGet(nameof(GetPatientDetails))]
        public IActionResult GetPatientDetails()
        {
            return Ok(_context.GetEmployeeWithDpt());
        }
    }



    
}
