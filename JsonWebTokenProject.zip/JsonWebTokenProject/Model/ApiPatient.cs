﻿using System;
using System.Collections.Generic;

namespace JsonWebTokenProject.Model
{
    public partial class ApiPatient
    {
        public int PatientId { get; set; }
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string? PhoneNumber { get; set; }
        public DateTime? Dob { get; set; }
        public int CountryId { get; set; }
        public string UserName { get; set; } = null!;
        public bool IsActive { get; set; }
        public string? CreatedByl { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string? DeletedBy { get; set; }
        public DateTime? DeletedOn { get; set; }
        public bool IsDeleted { get; set; }
    }
}
