﻿using System;
using System.Collections.Generic;

namespace JsonWebTokenProject.Model
{
    public partial class ApiLogin
    {
        public int LoginId { get; set; }
        public string Username { get; set; } = null!;
        public string Password { get; set; } = null!;
    }
}
